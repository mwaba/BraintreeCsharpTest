﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
    * Test 2: 
    * 1. Check that the user enters an uneven number. 
    * 2. It must be greater than 1, but not larger than 30
    * 3. e.g. If user enters 9, it must draw a pyramid that looks like this:       

    *
   ***
  *****
 *******
*********

*/

namespace BraintreeCSharpTest
{
    internal class Test02
    {
        public static void Run()
        {
            string lengthAsText = "";

            while (lengthAsText != "0")
            {
                Console.Clear();
                Console.Write("Enter the base length of Pyramid (0 to exit): ");
                lengthAsText = Console.ReadLine();
                var length = int.Parse(lengthAsText);
                var spc = length + 4 - 1;
                int i, j,  k;

                Console.Clear();
                if (length != 0)
                {
                    // Your solution goes here
                   
                    for (i = 1; i <= length; i++)
                    {
                        for (k = spc; k >= 1; k--)
                        {
                            Console.Write(" ");
                        }

                        for (j = 1; j <= i; j++)
                            Console.Write("* ");
                        Console.Write("\n");
                        spc--;
                    }
                }

                //

                Console.WriteLine();
                    Console.WriteLine("Press enter");
                    Console.ReadLine();
                }
            }
        }
    }

