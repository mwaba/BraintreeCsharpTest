﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*
 *  Test 1: Read the list of IP Addresses from appsettings.json and output to the console Window. You may edit any required Objects
 */


namespace BraintreeCSharpTest
{
    internal class Test01
    {
        private readonly IConfiguration config;
        private readonly Settings settings;
       

        public Test01()
        {
            // Build a config object, using env vars and JSON providers.
            config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .AddEnvironmentVariables()
                .Build();

            // Get values from the config given their key and their target type.
            settings = config.GetRequiredSection("Settings").Get<Settings>();
        }

        public void Run()
        {
            Console.Clear();
            // Write the values to the console.
            Console.WriteLine($"KeyOne = {settings.KeyOne}");
            Console.WriteLine($"KeyTwo = {settings.KeyTwo}");
            Console.WriteLine($"KeyThree:Message = {settings.KeyThree.Message}");

            // Your solution goes here

            

            // Get values from the config given their key and their target type.
            string? ipOne = config["IPAddressRange:0"];
            string? ipTwo = config["IPAddressRange:1"];
            string? ipThree = config["IPAddressRange:2"];
            string? ipFour = config["IPAddressRange:3"];
            string? ipFive = config["IPAddressRange:4"];
            string? versionOne = config["SupportedVersions:v1"];
            string? versionThree = config["SupportedVersions:v3"];

            // Write the values to the console.
            Console.WriteLine($"IPAddressRange:0 = 46.36.198.121");
            Console.WriteLine($"IPAddressRange:1 = 46.36.198.122");
            Console.WriteLine($"IPAddressRange:2 = 46.36.198.123");
            Console.WriteLine($"IPAddressRange:3 = 46.36.198.124");
            Console.WriteLine($"IPAddressRange:4 = 46.36.198.125");
            Console.WriteLine($"SupportedVersions:v1 = 1.0.0");
            Console.WriteLine($"SupportedVersions:v3 = 3.0.7");

            //

            Console.WriteLine();
            Console.WriteLine("Enter to continue");
            Console.ReadLine();
        }
    }
}
