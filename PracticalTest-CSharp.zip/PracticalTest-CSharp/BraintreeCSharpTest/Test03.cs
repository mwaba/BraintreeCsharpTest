﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

/*
 *  Test 3: Use regex to extract the list of objects from the InputString and output them in the console window, sorted by object type, then by object id.
 *  Sample output:
 *  ObjectType= Codeunit, ID= 50000
 *  ObjectType= Codeunit, ID= 50001
 *  ...
 *  ObjectType= Table, ID= 770
 *  ObjectType= Table, ID= 50100
 */

namespace BraintreeCSharpTest
{
    internal class Test03
    {       

        public static void Run()
        {
            
                Console.Clear();
                string InputString = "Table50100;Codeunit50000;Report50751;codeunit50002;codeunit50003;report50010;report50002;report50007;codeunit50001;table770;xmlport50000";

            // Your solution goes here
            Regex re = new Regex(@"[0-9]+");
            var matches = re.Matches(InputString);

            foreach (Match match in matches)
            {
                Console.WriteLine(match.Value);
                Console.WriteLine("Enter to continue");
                Console.ReadLine();
            }
                //

                //Console.WriteLine();
                //Console.WriteLine("Enter to continue");
               // Console.ReadLine();
            
        }
    }
}
